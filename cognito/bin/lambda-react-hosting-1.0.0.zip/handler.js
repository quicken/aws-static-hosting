"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const routing_1 = require("./lib/routing");
const auth_1 = require("./lib/auth");
/**
 * Lambda@Edge authorization function for Cognito-protected React applications
 * @param event - API Gateway proxy event
 * @returns Authorization result - either continue to origin or redirect
 */
const handler = async (event) => {
    const requestPath = event.path;
    const isPublic = (0, routing_1.isPublicPath)(requestPath);
    // Handle SPA routes (check authorization)
    if ((0, routing_1.isSpaRoute)(requestPath)) {
        // Check authentication for protected routes
        if (!isPublic && !(await (0, auth_1.isAuthenticated)(event))) {
            return {
                statusCode: 302,
                headers: { Location: "/public/login" },
                body: "",
            };
        }
        // Authorized - let CloudFront serve the content
        return {
            statusCode: 200,
            body: "",
        };
    }
    else {
        // Asset requests return 404 - React apps should bundle assets or use CDN
        return {
            statusCode: 404,
            headers: {
                "Content-Type": "text/plain",
            },
            body: "Not Found",
        };
    }
};
exports.handler = handler;
